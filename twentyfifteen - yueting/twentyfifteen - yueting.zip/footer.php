<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>
	<section>
	</div><!-- .site-content -->
</section>
	<!-- 底部 
<section id="footer" class="">
	<div class="main w70">	<div class="login"><i class="icon-account_circle"></i>登录</div></div>
	
</section>
</div><!-- .site -->


<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/cmp.js"></script>
<script>var skin= $(".category-cmpskin").find("i").attr("skin");</script>
<script type='text/javascript' src="<?php bloginfo('template_url');?>/js/showcmp.js"/></script>

<script>
$(document).ready(function(){

$(".showmain").on("click",function(){
	$(".main").toggleClass("w70");
	//$(".content").toggleClass("huadong");
})

  $(".v-style>li").click(function(){
  var tag = $(this).attr("class")
  $(".fs4 li").filter(".tag-"+ tag).show();
	$(".fs4 li").not(".tag-"+ tag).hide();
	$(this).addClass("on").siblings().removeClass("on");
  })
  $(".showall").click(function(){
	$(".fs4 li").show();
  });
   $(".bt_close").click(function(){
	$("#cmplayer").css("top","100%");
  });
})

</script>

<?php wp_footer(); ?>
</body>
</html>
